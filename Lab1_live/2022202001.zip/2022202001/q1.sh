#!/bin/bash
grep -o "\ba\w*" $1

